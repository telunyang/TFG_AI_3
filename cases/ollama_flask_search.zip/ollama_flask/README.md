# Ollama Flask 聊天室｜Excel BM25 + DDGS 網路檢索

本專案延續第一階段 Flask 聊天室，保留原本單一 Ollama 模型、真正串流、多輪 `history.json`、重新整理恢復與清除聊天功能。新增兩種彼此獨立的檢索來源：

- **Excel BM25**：掃描 `data/` 內所有可讀 `.xlsx` 工作簿與工作表，依欄位名稱及抽樣內容自動選用適合的文字欄位，再以 `rank-bm25` 的 BM25L 和 `jieba`／英文規則斷詞建立索引。
- **DDGS 網路搜尋**：使用 `ddgs==9.16.1` 取得候選網址，再擷取公開 HTML 正文、分段並使用 BM25 與 query token 覆蓋率篩選。搜尋摘要只用於候選，不直接當作已驗證正文。

本次沒有提供學生 `.xlsx`，所以 `data/` 保持空白，不會放入虛構知識庫。網站第一次開啟時預設只勾選 DDGS；Excel 功能已完整保留，日後新增資料即可啟用。

## 專案結構

```text
ollama_flask/
├── app.py
├── retrieval.py
├── requirements.txt
├── README.md
├── .gitignore
├── data/
│   └── .gitkeep
└── templates/
    └── index.html
```

執行期間才會建立 `history.json`、`bm25_index.pkl` 和 `data/web_cache.xlsx`；這些執行期資料不會放入交付 ZIP。BM25 pickle 只載入本專案自行產生的本機快取，不要用其他來源的同名檔案覆蓋。

## Windows CMD：第一次安裝與啟動

請使用 Python 3.10 或更新版本。解壓縮 ZIP 後，在 Windows CMD 進入專案資料夾：

```bat
cd ollama_flask
python -m pip install -r requirements.txt
python app.py
```

瀏覽器開啟：

```text
http://127.0.0.1:5001
```

停止網站時，在 CMD 按 `Ctrl+C`。套件安裝完成後，之後進入 `ollama_flask` 資料夾只需執行：

```bat
python app.py
```

不需要另外執行建索引程式或啟動其他資料庫服務。

## Ollama 連線設定（沿用第一階段）

`app.py` 保留第一階段來源程式實際設定：

- 模型：`nemotron-3.5-bolt:e4b`
- Ollama API 根網址：原本設定的 ngrok host
- Timeout：120 秒
- System prompt：`你是一個知識淵博且樂於助人的 AI 助理。`
- `keep_alive="1h"`、`think=False`
- `temperature=1.0`、`top_k=64`、`top_p=0.95`

若要改用本機 Ollama，請在 `app.py` 將 `OLLAMA_HOST` 改成：

```python
OLLAMA_HOST = "http://localhost:11434"
```

若使用教師提供的 ngrok 服務，請將 `OLLAMA_HOST` 設為該服務的 API 根網址。遠端網址可能改變；請勿把 Ollama host 或金鑰貼到公開位置。

## 兩種檢索的 Checkbox

檢索設定只影響當輪提問。預設勾選不會自動搜尋，必須由使用者送出問題後才會執行。四種組合如下：

| Excel BM25 | DDGS | 本輪行為 |
|---|---|---|
| 不勾選 | 不勾選 | 原本的 Ollama 多輪聊天，不呼叫檢索 |
| 勾選 | 不勾選 | 只查 Excel；空知識庫或未命中時回到一般聊天，不會呼叫 DDGS |
| 不勾選 | 勾選 | 只執行 DDGS 網路搜尋 |
| 勾選 | 勾選 | 分別執行 Excel 與 DDGS，整合各自達標的證據 |

沒有 Excel 時，第一次開啟網頁預設只勾選 DDGS。放入有效 Excel 並重新整理網頁後，Excel 檢索可勾選使用；有 Excel 時兩個來源預設均不勾選。勾選 DDGS 表示本輪問題的搜尋詞會送到外部搜尋服務，不會把 Excel 內容或整份聊天歷史傳給 DDGS。

「網路搜尋設定」內可勾選「強制刷新網路快取」，只會在本輪 DDGS 已啟用時生效。

## 如何判斷回答是否真的使用檢索資料

新版會在每一則 AI 回答下方顯示「檢索證據狀態」，不再只在有來源連結時才顯示資訊：

- **已使用檢索資料**：本輪確實將 Excel／網頁正文放入模型的本輪參考內容；下方會列出有合法網址的實際來源，並依 Excel／網路分組。
- **部分檢索成功**：至少一個來源成功提供證據，但另一個來源可能搜尋失敗或未達門檻；狀態文字會列出部分失敗原因。
- **未取得可用檢索資料**：本輪沒有達標證據，模型仍會回答，但答案是一般模型生成，沒有本輪檢索資料支持。
- **一般聊天／未啟用檢索**：兩個 Checkbox 都未勾選，完全沒有執行 Excel 或 DDGS 檢索。
- **舊版對話**：舊紀錄沒有保存檢索狀態，畫面會明確說明無法回溯確認。

來源連結只會顯示本輪實際提供給模型且具有合法 HTTP(S) 網址的資料；Excel 列若沒有來源網址，會標示已使用檢索資料但沒有可顯示的網址，不會虛構連結。請點擊來源自行核對原文。**有來源不等於回答每一句都已被證實**：模型仍可能誤讀、過度推論或加入來源未支持的內容，重要資訊應回到原始頁面確認。檢索狀態與來源會隨成功回答保存於 `history.json`，重新整理後仍可查看。

## 新增 Excel 知識庫

1. 將 `.xlsx` 檔案放入 `ollama_flask/data/`。
2. 每個工作表第一列應是欄位標題；程式會抽樣前 20 筆非空白資料，並參考欄名與內容辨識文字欄位、標題欄位及來源網址欄位。
3. 每一筆非空白資料列會組成一筆文件，使用適合檢索的多個文字欄位（如標題、摘要、內文、關鍵字）；網址只作為來源連結，不會當成主要檢索語料。
4. 重新啟動網站，或在既有網站下一次執行 Excel 查詢時，程式會依檔案 SHA-256 檢查索引是否需要更新。新增、刪除或修改 Excel 後會自動重建；資料未變動時會載入專案本機產生的 BM25 pickle 索引。
5. 若自動欄位判斷不符合資料內容，可在 `retrieval.py` 上方的 `SHEET_COLUMN_OVERRIDES` 依 `檔名::工作表名稱` 設定 `text_columns`、`url_columns`、`title_index`（欄位索引從 0 開始）。

略過 Excel 暫存檔、`web_cache.xlsx` 及其暫存檔。請勿將含個資或敏感資料的工作簿放入知識庫。Excel 及網頁內容都只當作參考資料，不會被當成系統指令執行。

## BM25 設定

在 `retrieval.py` 可調整：

```python
TOP_K = 3
MIN_BM25_SCORE = 0.1
MAX_CONTEXT_CHARS = 4500
```

BM25 分數不是 0 到 1 的語意相似度機率，也不是答案正確率。`MIN_BM25_SCORE` 是課堂起始門檻，請依自己的資料量與查詢測試後調整。只有達門檻且至少與 query 共用一個有效 token 的文件才會提供給模型。空資料、空 query 或沒有匹配結果時會安全回退到一般聊天。

中英文共用同一個 tokenizer：中文以 `jieba.lcut()` 斷詞；英文與數字以規則擷取並統一小寫。沒有安裝 `jieba`／`rank-bm25` 時，請先按前述安裝步驟安裝 `requirements.txt`。

## DDGS 正文檢索與網頁快取

主要設定集中在 `retrieval.py`：

- DDGS 候選上限：20
- 最多引用來源：8（實際數量依正文與相關性決定）
- 網頁候選相關性起始門檻：0.5
- 搜尋列表快取 TTL：1 小時；成功空結果 TTL：10 分鐘
- 一般網頁正文 TTL：7 天；新聞正文 TTL：1 天
- 單頁 timeout：10 秒；網路檢索整體 deadline：60 秒
- 正文單頁快取文字最多保留 32,000 字元，避免超過 Excel 儲存格上限

DDGS 搜尋候選會依 URL 去重；只對合法公開 HTTP(S) 網址擷取 HTML，重新導向每一跳都重新解析及驗證公開 IP，並將 TCP 連線固定到已驗證 IP，以降低 DNS rebinding／SSRF 風險。程式不繞過登入、付費牆或反爬機制。非 HTML、403／429、timeout、無正文或無足夠關鍵字重疊的網頁不會當成證據。搜尋異常不會阻止一般 Ollama 聊天或另一種檢索來源。

`data/web_cache.xlsx` 有 `queries`、`pages`、`chunks` 三個工作表。查詢列表預設快取 1 小時，正文依一般網頁／新聞 TTL 快取；相同 URL 的正文列會更新而非無限重複新增，chunk ID 會去重。過期頁面會嘗試用 ETag／Last-Modified 條件式請求；304 時沿用未變更正文並更新期限。強制刷新可跳過有效查詢快取並重新驗證／擷取頁面。網頁快取完全獨立，不會被納入 Excel BM25 索引。

清除聊天只會刪除 `history.json`，不會刪除學生 Excel、BM25 索引或網頁快取。


## DDGS 問題診斷

如果網路搜尋失敗，程式會將檢索例外記錄在啟動 Flask 的 CMD 視窗，顯示完整 traceback；同時略過失敗的檢索來源，嘗試以一般聊天繼續回答。只有確實發生在 Ollama 模型生成階段的例外，才會顯示 Ollama 連線／模型錯誤。請保留 CMD 視窗中的 `Request failed during stage` 或 `Unexpected DDGS retrieval failure` 記錄，這些才是判斷實際原因的依據。

本版本另修正一項 BM25 排序相容性問題：`rank-bm25` 的 `get_scores()` 會回傳 NumPy 陣列，不能用 `if raw_scores` 判斷是否有資料，否則會觸發 `ValueError: The truth value of an array with more than one element is ambiguous`。目前改用 `len(raw_scores) > 0` 判斷，並新增 NumPy 陣列回歸測試。若你遇到相同錯誤，請確認執行的是本 ZIP 中新版 `retrieval.py`，不是舊版檔案。

若 DDGS 顯示搜尋錯誤，先確認電腦可連上外網、沒有防火牆／代理阻擋，再於專案資料夾確認套件：

```bat
python -m pip show ddgs requests beautifulsoup4
python -m pip check
```

若剛安裝或更新過套件，請停止 Flask 後重新安裝：

```bat
python -m pip install -r requirements.txt
python app.py
```

## 舊版對話紀錄移轉

若要在新版本接續第一階段對話：

1. 先回到舊版網站所在的 CMD 視窗，按 `Ctrl+C` 停止舊網站。
2. 將舊版專案根目錄的 `history.json` 複製到新版 `ollama_flask` 根目錄。
3. 再於新版資料夾執行 `python app.py`。

例如舊版資料夾叫 `ollama_flask_old`，且新版資料夾位於同一層，可在新版 CMD 執行：

```bat
copy ..\ollama_flask_old\history.json .\history.json
```

新版可直接讀取舊版只有 `role`／`content` 的紀錄；之後新的 AI 回覆才會選擇性附帶來源 metadata。ZIP 不包含個人對話檔，請自行備份並保管。

## API 相容性

| 方法 | 路由 | 說明 |
|---|---|---|
| GET | `/` | 聊天首頁 |
| GET | `/api/history` | 取得多輪歷史與已保存來源 |
| POST | `/api/chat/stream` | NDJSON 聊天串流 |
| POST | `/api/clear` | 清除聊天歷史 |

新版 `/api/chat/stream` 支援：

```json
{"message":"問題", "use_retrieval":true, "use_web_search":false, "force_refresh":false}
```

舊版只傳 `message` 或 `message` 加 `use_retrieval` 的請求仍相容；缺少的旗標預設 `false`。旗標必須為 JSON boolean，否則回傳 HTTP 400。NDJSON 保留 `chunk`、`done`、`error`，另新增 `retrieval_status`、成功保存後的 `sources` 與 `retrieval_result` 事件。

## 測試與目前驗證範圍

本交付環境已執行 Python 語法編譯與 JavaScript 語法檢查，並通過 21 項離線 mock 測試，涵蓋 Excel schema 推斷、中英混合 tokenizer 的替身測試、BM25L 替身分數排序、索引快取／重建、DDGS 與網頁擷取 mock、正文 HTML 清理、URL／SSRF／redirect 防護、429 Retry-After 重試、快取工作簿，以及 Flask／Ollama 替身路由的四種 Checkbox、多輪歷史、來源狀態保存／還原、無網址資料提示與來源相容。

**限制：** 產生 ZIP 的執行環境沒有安裝 Flask、Ollama Python SDK、`rank-bm25`、`jieba`、`ddgs`，且無法連外安裝套件。因此此環境無法啟動真實 Flask server、執行正式 `rank-bm25` BM25L／`jieba`／DDGS 搜尋（tokenization、BM25 分數測試使用替身實作），也未連線測試遠端 ngrok Ollama 模型。請在自己的 Windows 環境先安裝 `requirements.txt`；真實模型回答仍需能連線到原本 Ollama host，DDGS 正文檢索則需要外部網路。

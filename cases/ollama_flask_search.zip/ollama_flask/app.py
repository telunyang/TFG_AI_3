'''
Define the project settings and the original Ollama configuration.
'''

'''
集中設定專案路徑、Ollama 主機與來源模型參數。
'''

'''
Import the Flask, Ollama, and standard-library tools used by the server.
'''

'''
匯入伺服器實際使用的 Flask、Ollama 與 Python 標準函式庫。
'''

'''
Import JSON tools for reading and writing conversation history.
'''
'''
匯入讀取與寫入對話歷史所需的 JSON 工具。
'''
import json

'''
Import logging support for concise server error records.
'''
'''
匯入記錄伺服器簡要錯誤訊息的 logging 工具。
'''
import logging

'''
Import operating-system helpers for atomic files and cleanup.
'''
'''
匯入執行原子檔案替換與清理作業的作業系統工具。
'''
import os

'''
Import temporary file support for safe history updates.
'''
'''
匯入建立安全歷史紀錄暫存檔的工具。
'''
import tempfile

'''
Import thread locks to protect shared conversation state.
'''
'''
匯入執行緒鎖以保護共用對話狀態。
'''
import threading

'''
Import Path for project-relative file locations.
'''
'''
匯入 Path 以處理相對於專案的檔案路徑。
'''
from pathlib import Path

'''
Import the Flask components required by the web routes.
'''
'''
匯入網站路由需要的 Flask 元件。
'''
from flask import Flask, Response, jsonify, render_template, request, stream_with_context

'''
Import the official Ollama Python client.
'''
'''
匯入官方 Ollama Python 用戶端。
'''
from ollama import Client

from retrieval import RetrievalUnavailableError, build_retrieval_prompt, excel_search, get_index_count, web_search


'''
Keep the original ngrok root URL from the supplied single-turn program.
'''

'''
保留上傳單輪程式中實際設定的 ngrok API 根網址。
'''
OLLAMA_HOST = "https://1f23-136-85-195-93.ngrok-free.app"

'''
Keep the model name, timeout, system instruction, and generation options unchanged.
'''

'''
保留來源程式的模型名稱、逾時時間、系統提示詞與生成參數。
'''
MODEL_NAME = "nemotron-3.5-bolt:e4b"

'''
Set the request timeout used by the original Ollama client.
'''
'''
設定來源 Ollama 用戶端使用的請求逾時秒數。
'''
OLLAMA_TIMEOUT = 120

'''
Keep the original system instruction sent to the model.
'''
'''
保留來源程式傳給模型的原始系統提示詞。
'''
SYSTEM_PROMPT = "你是一個知識淵博且樂於助人的 AI 助理。"

'''
Keep the original model lifetime setting after each request.
'''
'''
保留來源程式每次請求後的模型保留時間設定。
'''
KEEP_ALIVE = "1h"

'''
Disable thinking as specified by the supplied Python program.
'''
'''
依照上傳程式的設定，關閉模型思考模式。
'''
THINK = False

'''
Keep the original temperature, top-k, and top-p generation options.
'''
'''
保留來源程式的 temperature、top-k 與 top-p 生成參數。
'''
MODEL_OPTIONS = {
    "temperature": 1.0,
    "top_k": 64,
    "top_p": 0.95,
}

'''
Set the local Flask address and the maximum accepted message size.
'''

'''
設定本機 Flask 網址與單則訊息的最大字數。
'''
HOST = "127.0.0.1"

'''
Set the Flask listening port for the classroom website.
'''
'''
設定教學網站使用的 Flask 監聽埠號。
'''
PORT = 5001

'''
Limit the maximum number of characters in one submitted message.
'''
'''
限制單次送出訊息的最大字元數。
'''
MAX_MESSAGE_LENGTH = 10000

'''
Resolve the project folder and the persistent conversation file.
'''

'''
取得專案根目錄與持久化對話紀錄檔的路徑。
'''
BASE_DIR = Path(__file__).resolve().parent

'''
Set the history file path at the root of this project.
'''
'''
將歷史紀錄檔路徑固定在本專案根目錄。
'''
HISTORY_FILE = BASE_DIR / "history.json"

'''
Create the Flask application and its Ollama client without contacting the model.
'''

'''
建立 Flask 應用程式與 Ollama 用戶端，但啟動時不連線模型。
'''
app = Flask(__name__)

'''
Create the Ollama client with the original host and timeout.
'''
'''
使用來源程式的主機網址與逾時設定建立 Ollama 用戶端。
'''
client = Client(host=OLLAMA_HOST, timeout=OLLAMA_TIMEOUT)

'''
Protect history file operations and allow only one active generation at a time.
'''

'''
使用鎖保護歷史檔案，並限制同一時間只能有一輪生成作業。
'''
history_lock = threading.Lock()

'''
Create a separate lock for single active model generation.
'''
'''
另外建立鎖，限制同一時間只能生成一輪回答。
'''
generation_lock = threading.Lock()

'''
Configure concise server logging without exposing conversation content.
'''

'''
設定精簡伺服器記錄，避免輸出使用者對話內容。
'''
app.logger.setLevel(logging.INFO)


'''
Read valid user and assistant messages from the JSON history file.
'''

'''
從 JSON 歷史檔讀取有效的 user 與 assistant 訊息。
'''
def load_history():
    '''
    Return an empty conversation when the history file has not been created.
    '''
    '''
    尚未建立歷史檔時，回傳空的對話紀錄。
    '''
    if not HISTORY_FILE.exists():
        '''
        Return an empty list when no successful turn has been saved.
        '''
        '''
        尚未保存任何成功回合時，回傳空清單。
        '''
        return []

    '''
    Open the history file as UTF-8 and parse its JSON content.
    '''
    '''
    以 UTF-8 開啟歷史檔，並解析其中的 JSON 內容。
    '''
    with HISTORY_FILE.open("r", encoding="utf-8") as history_file:
        '''
        Parse the UTF-8 JSON history from the opened file.
        '''
        '''
        從已開啟的檔案解析 UTF-8 JSON 歷史紀錄。
        '''
        raw_history = json.load(history_file)

    '''
    Reject unexpected top-level data instead of silently changing the history.
    '''
    '''
    若最外層資料格式不正確，明確拒絕而不擅自修改紀錄。
    '''
    if not isinstance(raw_history, list):
        '''
        Raise an error when the history is not stored as a list.
        '''
        '''
        歷史紀錄不是清單格式時，明確拋出錯誤。
        '''
        raise ValueError("history.json 的最外層必須是 JSON 陣列。")

    '''
    Keep only messages with supported roles and plain text content.
    '''
    '''
    僅保留角色正確且內容為文字的訊息。
    '''
    cleaned_history = []

    '''
    Validate each saved message before passing it to Ollama.
    '''
    '''
    將每筆已儲存訊息逐一檢查後再交給 Ollama。
    '''
    for item in raw_history:
        '''
        Accept only user or assistant messages with string content.
        '''
        '''
        只接受 content 為文字的 user 或 assistant 訊息。
        '''
        if isinstance(item, dict) and item.get("role") in ("user", "assistant") and isinstance(item.get("content"), str):
            '''
            Copy only the two fields required by the Ollama chat API.
            '''
            '''
            只複製 Ollama 對話 API 必要的 role 與 content 欄位。
            '''
            clean_item = {"role": item["role"], "content": item["content"]}
            if item["role"] == "assistant":
                if isinstance(item.get("sources"), list):
                    safe_sources = []
                    for source in item["sources"]:
                        if not isinstance(source, dict):
                            continue
                        source_url = source.get("url")
                        if not isinstance(source_url, str) or not source_url.lower().startswith(("http://", "https://")):
                            continue
                        safe_sources.append({key: value for key, value in source.items()
                                             if key in {"title", "url", "source_type", "source_id", "file", "sheet", "row", "fetched_at", "published_date", "cache_hit"}
                                             and isinstance(value, (str, int, float, bool))})
                    if safe_sources:
                        clean_item["sources"] = safe_sources

                retrieval = item.get("retrieval")
                if isinstance(retrieval, dict):
                    allowed_statuses = {"not_requested", "used", "partial", "not_found"}
                    status_value = retrieval.get("status")
                    if status_value in allowed_statuses:
                        clean_item["retrieval"] = {
                            "status": status_value,
                            "message": str(retrieval.get("message", ""))[:600],
                            "requested_excel": bool(retrieval.get("requested_excel", False)),
                            "requested_web": bool(retrieval.get("requested_web", False)),
                            "excel_count": retrieval.get("excel_count", 0) if isinstance(retrieval.get("excel_count", 0), int) and not isinstance(retrieval.get("excel_count", 0), bool) and retrieval.get("excel_count", 0) >= 0 else 0,
                            "web_count": retrieval.get("web_count", 0) if isinstance(retrieval.get("web_count", 0), int) and not isinstance(retrieval.get("web_count", 0), bool) and retrieval.get("web_count", 0) >= 0 else 0,
                            "source_count": retrieval.get("source_count", 0) if isinstance(retrieval.get("source_count", 0), int) and not isinstance(retrieval.get("source_count", 0), bool) and retrieval.get("source_count", 0) >= 0 else 0,
                        }
            cleaned_history.append(clean_item)

    '''
    Return the validated conversation in its original order.
    '''
    '''
    依照原本順序回傳通過檢查的對話紀錄。
    '''
    return cleaned_history


'''
Write the complete history through a temporary file and atomic replacement.
'''

'''
先寫入暫存檔，再以原子替換方式保存完整歷史紀錄。
'''
def save_history(history):
    '''
    Remember the temporary file path so it can be removed after any failure.
    '''
    '''
    記錄暫存檔路徑，以便發生錯誤時清除未完成的檔案。
    '''
    temporary_path = None

    '''
    Write and replace the history file as one protected operation.
    '''
    '''
    將歷史資料寫入並替換正式檔案，避免留下半份 JSON。
    '''
    try:
        '''
        Create the temporary file in the project folder using UTF-8 encoding.
        '''
        '''
        在專案根目錄建立 UTF-8 編碼的暫存檔。
        '''
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=BASE_DIR,
            prefix=".history-",
            suffix=".tmp",
            delete=False,
        ) as temporary_file:
            '''
            Remember the path before writing so cleanup can find the file.
            '''
            '''
            寫入前先記住暫存檔路徑，讓後續清理能找到檔案。
            '''
            temporary_path = temporary_file.name

            '''
            Store readable JSON without escaping Traditional Chinese characters.
            '''
            '''
            儲存容易閱讀的 JSON，並保留繁體中文字元。
            '''
            json.dump(history, temporary_file, ensure_ascii=False, indent=2)

            '''
            Flush buffered data and request that the operating system sync it.
            '''
            '''
            清空檔案緩衝區，並要求作業系統同步寫入資料。
            '''
            temporary_file.flush()

            '''
            Sync the temporary file contents to the operating system.
            '''
            '''
            要求作業系統同步暫存檔的內容。
            '''
            os.fsync(temporary_file.fileno())

        '''
        Atomically replace the previous history with the completed new file.
        '''
        '''
        以完整的新檔案原子替換舊的歷史紀錄。
        '''
        os.replace(temporary_path, HISTORY_FILE)

        '''
        Clear the temporary path after the replacement succeeds.
        '''
        '''
        替換成功後清除暫存檔路徑記錄。
        '''
        temporary_path = None

    finally:
        '''
        Delete the temporary file only when it still exists.
        '''
        '''
        僅在暫存檔仍存在時才執行刪除。
        '''
        if temporary_path is not None and os.path.exists(temporary_path):
            '''
            Remove the leftover temporary file from the project folder.
            '''
            '''
            從專案資料夾移除遺留的暫存檔。
            '''
            os.remove(temporary_path)


'''
Convert an Ollama stream item into its plain text content.
'''

'''
將 Ollama 串流資料轉換成純文字內容。
'''
def extract_chunk_text(stream_item):
    '''
    Read the message value from either an SDK object or a dictionary.
    '''
    '''
    同時支援 SDK 物件與字典格式的 message 欄位。
    '''
    message = getattr(stream_item, "message", None)

    '''
    Support dictionary-shaped stream items used by compatible clients.
    '''
    '''
    相容於以字典表示的串流資料。
    '''
    if message is None and isinstance(stream_item, dict):
        '''
        Retrieve the message dictionary when the stream item is a dictionary.
        '''
        '''
        當串流資料是字典時，取出其中的 message。
        '''
        message = stream_item.get("message", {})

    '''
    Read content from the message according to its data type.
    '''
    '''
    依照 message 的資料型態讀取 content。
    '''
    if isinstance(message, dict):
        '''
        Get text safely from a dictionary message.
        '''
        '''
        從字典格式的 message 安全取得文字。
        '''
        content = message.get("content", "")
    else:
        '''
        Get text safely from an Ollama SDK message object.
        '''
        '''
        從 Ollama SDK 的 message 物件安全取得文字。
        '''
        content = getattr(message, "content", "")

    '''
    Ignore non-string content so only text reaches the browser.
    '''
    '''
    忽略非文字內容，確保傳給瀏覽器的資料只有文字。
    '''
    return content if isinstance(content, str) else ""


'''
Translate common Ollama failures into clear messages without exposing internals.
'''

'''
將常見 Ollama 錯誤轉成易懂訊息，避免洩漏內部資訊。
'''
def friendly_ollama_error(error):
    '''
    Inspect a lowercase copy of the exception text for known failure patterns.
    '''
    '''
    將例外訊息轉成小寫，以比對常見錯誤類型。
    '''
    detail = str(error).lower()

    '''
    Read the HTTP status when the Ollama exception provides one.
    '''
    '''
    若 Ollama 例外包含 HTTP 狀態碼，便讀取該數值。
    '''
    status_code = getattr(error, "status_code", None)

    '''
    Explain rate limits and exhausted remote service quotas.
    '''
    '''
    說明請求頻率限制或遠端服務額度不足的情況。
    '''
    if status_code == 429 or "too many requests" in detail or "quota" in detail or "rate limit" in detail:
        '''
        Return guidance for a service request limit or quota failure.
        '''
        '''
        回傳服務請求頻率或額度不足時的處理建議。
        '''
        return "Ollama 服務目前達到請求或額度限制，請稍後再試或確認遠端服務額度。"

    '''
    Explain when the configured model is unavailable on the Ollama server.
    '''
    '''
    說明 Ollama 伺服器找不到目前設定的模型時該如何處理。
    '''
    if "model" in detail and ("not found" in detail or "does not exist" in detail):
        '''
        Return the exact model name and its local download command.
        '''
        '''
        回傳實際模型名稱與本機下載指令。
        '''
        return f"找不到模型 {MODEL_NAME}。請確認模型名稱，或在本機執行 ollama pull {MODEL_NAME}。"

    '''
    Explain a missing model or resource reported by the server.
    '''
    '''
    說明伺服器回報找不到模型或資源的情況。
    '''
    if status_code == 404 or "not found" in detail:
        '''
        Return a helpful message for a missing Ollama resource.
        '''
        '''
        資源不存在時，回傳檢查模型是否存在的提示。
        '''
        return f"Ollama 找不到指定資源，請確認伺服器上有模型 {MODEL_NAME}。"

    '''
    Explain authentication or access rejection from a remote endpoint.
    '''
    '''
    說明遠端端點拒絕驗證或存取的情況。
    '''
    if status_code in (401, 403) or "unauthorized" in detail or "forbidden" in detail:
        '''
        Return access guidance for an endpoint that rejects the request.
        '''
        '''
        遠端端點拒絕請求時，回傳檢查存取設定的提示。
        '''
        return "Ollama 遠端服務拒絕連線，請確認服務網址與遠端存取設定。"

    '''
    Explain connection and DNS failures without printing the endpoint details.
    '''
    '''
    說明連線或 DNS 失敗，但不輸出端點的內部細節。
    '''
    if any(term in detail for term in ("connection", "connect", "refused", "dns", "name or service", "getaddrinfo")):
        '''
        Return endpoint troubleshooting guidance without echoing the URL.
        '''
        '''
        不重複輸出網址，僅回傳檢查連線端點的建議。
        '''
        return "無法連線到 Ollama。請確認 Ollama 服務已啟動，並檢查 app.py 的 OLLAMA_HOST。"

    '''
    Explain a request timeout from the Ollama server.
    '''
    '''
    說明 Ollama 伺服器逾時的情況。
    '''
    if "timeout" in detail or "timed out" in detail:
        '''
        Return a retry suggestion when the Ollama request times out.
        '''
        '''
        Ollama 請求逾時時，回傳稍後重試的建議。
        '''
        return "等待 Ollama 回應逾時，請確認模型仍在運作，或稍後再試。"

    '''
    Return a safe generic error for any other Ollama failure.
    '''
    '''
    其他 Ollama 錯誤一律回傳不含敏感內容的通用訊息。
    '''
    return "Ollama 回應失敗，請檢查模型設定、伺服器狀態與遠端服務額度。"


'''
Encode one event as a newline-terminated NDJSON record.
'''

'''
將單一事件編碼成以換行結尾的 NDJSON 紀錄。
'''
def encode_event(event):
    '''
    Serialize the event while preserving Traditional Chinese text.
    '''
    '''
    序列化事件時保留繁體中文字元。
    '''
    return json.dumps(event, ensure_ascii=False) + "\n"


'''
Render the single-page chat interface.
'''

'''
顯示單頁式聊天介面。
'''
@app.get("/")
def index():
    '''
    Return the HTML template without requiring an active Ollama connection.
    '''
    '''
    回傳 HTML 頁面，不要求 Ollama 服務必須先連線成功。
    '''
    try:
        has_excel = get_index_count() > 0
    except Exception as error:
        app.logger.warning("Excel index check failed: %s", type(error).__name__)
        has_excel = False
    return render_template("index.html", has_excel=has_excel)


'''
Return the conversation currently stored on the server.
'''

'''
回傳伺服器目前儲存的對話紀錄。
'''
@app.get("/api/history")
def get_history():
    '''
    Read the history while holding the history lock.
    '''
    '''
    讀取歷史紀錄時先取得歷史檔案鎖。
    '''
    try:
        '''
        Prevent simultaneous writes while reading the JSON file.
        '''
        '''
        讀取 JSON 檔時避免同時發生寫入作業。
        '''
        with history_lock:
            '''
            Load the validated message list from disk.
            '''
            '''
            從磁碟載入並檢查訊息清單。
            '''
            history = load_history()

        '''
        Return the messages in a consistent API response shape.
        '''
        '''
        以固定的 API 回應格式回傳訊息。
        '''
        return jsonify({"messages": history})

    except (OSError, ValueError, json.JSONDecodeError):
        '''
        Return a clear message asking the user to inspect the history file.
        '''
        '''
        回傳清楚訊息，提醒使用者檢查歷史紀錄檔。
        '''
        return jsonify({"error": "無法讀取 history.json，請檢查檔案格式或存取權限。"}), 500


'''
Accept one user message and stream the real Ollama response as NDJSON.
'''

'''
接收一則使用者訊息，並以 NDJSON 串流傳送 Ollama 真實回覆。
'''
@app.post("/api/chat/stream")
def chat_stream():
    '''
    Parse and validate the single message sent by the browser.
    '''
    '''
    解析並檢查瀏覽器送來的單則訊息。
    '''
    payload = request.get_json(silent=True)

    '''
    Reject requests that do not contain a JSON object.
    '''
    '''
    拒絕未提供 JSON 物件的請求。
    '''
    if not isinstance(payload, dict):
        '''
        Reject a request body that is not a JSON object.
        '''
        '''
        拒絕不是 JSON 物件的請求內容。
        '''
        return jsonify({"error": "請以 JSON 格式傳送 message。"}), 400

    '''
    Normalize the message and reject empty or excessively long input.
    '''
    '''
    整理訊息文字，並拒絕空白或過長的輸入。
    '''
    user_message = payload.get("message")

    '''
    Require a non-empty string as the user message.
    '''
    '''
    使用者訊息必須是非空白字串。
    '''
    if not isinstance(user_message, str) or not user_message.strip():
        '''
        Ask the browser to provide a non-empty question.
        '''
        '''
        提醒瀏覽器必須提供非空白問題。
        '''
        return jsonify({"error": "請先輸入問題。"}), 400

    '''
    Trim surrounding whitespace before sending the question to the model.
    '''
    '''
    傳送問題前先移除前後多餘空白。
    '''
    user_message = user_message.strip()

    '''
    Enforce a simple size limit for classroom use.
    '''
    '''
    設定適合教學使用的單則訊息字數上限。
    '''
    if len(user_message) > MAX_MESSAGE_LENGTH:
        '''
        Reject questions that exceed the configured length limit.
        '''
        '''
        拒絕超過設定字數上限的問題。
        '''
        return jsonify({"error": f"單則訊息不可超過 {MAX_MESSAGE_LENGTH} 個字元。"}), 400

    '''
    Prevent overlapping generations and reject a second active request.
    '''
    '''
    避免同時執行多輪生成，並拒絕重疊的第二個請求。
    '''
    use_retrieval = payload.get("use_retrieval", False)
    use_web_search = payload.get("use_web_search", False)
    force_refresh = payload.get("force_refresh", False)
    if not all(isinstance(value, bool) for value in (use_retrieval, use_web_search, force_refresh)):
        return jsonify({"error": "use_retrieval、use_web_search 與 force_refresh 必須是布林值。"}), 400

    if not generation_lock.acquire(blocking=False):
        '''
        Reject a new request while another answer is being generated.
        '''
        '''
        另一則回答正在生成時，拒絕新的聊天請求。
        '''
        return jsonify({"error": "目前已有一則訊息正在回答，請等候完成。"}), 409

    '''
    Load the stored conversation before constructing the next model request.
    '''
    '''
    建立下一次模型請求前，先從後端讀取已儲存的對話。
    '''
    try:
        '''
        Protect the history read from concurrent access.
        '''
        '''
        讀取對話紀錄時使用歷史檔案鎖保護。
        '''
        with history_lock:
            '''
            Load only the validated user and assistant messages.
            '''
            '''
            只載入通過檢查的 user 與 assistant 訊息。
            '''
            history = load_history()

    except (OSError, ValueError, json.JSONDecodeError):
        '''
        Unlock the generation slot after the preflight failure.
        '''
        '''
        前置檢查失敗後，釋放生成作業的鎖。
        '''
        generation_lock.release()

        '''
        Return an error without starting the Ollama request.
        '''
        '''
        不啟動 Ollama 請求，直接回傳錯誤。
        '''
        return jsonify({"error": "無法讀取 history.json，請檢查檔案格式或存取權限。"}), 500

    '''
    Build the model context with one system message followed by saved turns.
    '''
    '''
    建立模型上下文，只放一筆 system，再接續已儲存的對話。
    '''
    model_history = [{"role": item["role"], "content": item["content"]} for item in history]
    messages = [{"role": "system", "content": SYSTEM_PROMPT}] + model_history + [
        {"role": "user", "content": user_message}
    ]

    '''
    Stream model chunks and persist the turn only after complete success.
    '''
    '''
    逐段傳送模型文字，只有完整成功後才寫入本輪對話。
    '''
    def generate():
        '''
        Collect the complete assistant response without saving partial output.
        '''
        '''
        收集完整的 assistant 回覆，過程中不保存半成品。
        '''
        full_response = ""
        current_stage = "檢索初始化"

        '''
        Keep all stream work inside a try block so the generation lock is released.
        '''
        '''
        將串流工作放在 try 區塊內，確保最後一定釋放生成鎖。
        '''
        try:
            excel_items = []
            web_items = []
            source_items = []
            retrieval_problems = []

            if use_retrieval:
                current_stage = "Excel BM25 檢索"
                yield encode_event({"type": "retrieval_status", "message": "正在查詢 Excel BM25…"})
                try:
                    excel_items, excel_status = excel_search(user_message)
                    if excel_status == "empty":
                        retrieval_problems.append("尚未找到可用的 Excel 資料")
                    elif excel_status == "no_match":
                        retrieval_problems.append("Excel BM25 沒有找到達標資料")
                except RetrievalUnavailableError as error:
                    app.logger.warning("Excel retrieval unavailable: %s", type(error).__name__)
                    retrieval_problems.append(str(error))
                except Exception as error:
                    app.logger.exception("Unexpected Excel retrieval failure")
                    retrieval_problems.append(f"Excel 檢索發生未預期錯誤（{type(error).__name__}）")

            if use_web_search:
                current_stage = "DDGS 網路搜尋與正文擷取"
                yield encode_event({"type": "retrieval_status", "message": "正在使用 DDGS 搜尋網路…"})
                try:
                    is_news_query = "新聞" in user_message or "news" in user_message.casefold()
                    web_items, web_status = web_search(user_message, force_refresh=force_refresh, news=is_news_query)
                    if web_status.get("status") == "error":
                        retrieval_problems.append(web_status.get("message", "網路搜尋失敗"))
                    elif not web_items:
                        retrieval_problems.append("DDGS 未取得符合相關性門檻的網頁正文")
                except RetrievalUnavailableError as error:
                    app.logger.warning("Web retrieval unavailable: %s", type(error).__name__)
                    retrieval_problems.append(str(error))
                except Exception as error:
                    app.logger.exception("Unexpected DDGS retrieval failure")
                    retrieval_problems.append(f"DDGS 檢索發生未預期錯誤（{type(error).__name__}）")

            current_stage = "檢索證據整理"
            enhanced_prompt, source_items = build_retrieval_prompt(excel_items, web_items, user_message)
            has_retrieved_evidence = enhanced_prompt != user_message
            used_excel_count = enhanced_prompt.count("[Excel 資料 E")
            used_web_count = enhanced_prompt.count("[網路資料 W")
            if not use_retrieval and not use_web_search:
                retrieval_info = {
                    "status": "not_requested",
                    "message": "本輪未啟用 Excel 或網路檢索；以下回答是模型一般聊天內容，未經外部資料查證。",
                    "requested_excel": False, "requested_web": False,
                    "excel_count": 0, "web_count": 0, "source_count": 0,
                }
            elif has_retrieved_evidence:
                status_value = "partial" if retrieval_problems else "used"
                summary_parts = []
                if used_excel_count:
                    summary_parts.append(f"Excel {used_excel_count} 筆")
                if used_web_count:
                    summary_parts.append(f"網路 {used_web_count} 筆")
                evidence_summary = "、".join(summary_parts) or "檢索資料"
                retrieval_message = f"已將 {evidence_summary} 加入模型參考資料。"
                if not source_items:
                    retrieval_message += "這些資料沒有可顯示的有效來源網址。"
                if retrieval_problems:
                    retrieval_message += "部分檢索未成功：" + "；".join(retrieval_problems)
                retrieval_info = {
                    "status": status_value, "message": retrieval_message,
                    "requested_excel": use_retrieval, "requested_web": use_web_search,
                    "excel_count": used_excel_count, "web_count": used_web_count,
                    "source_count": len(source_items),
                }
            else:
                detail = "；".join(retrieval_problems) if retrieval_problems else "未取得符合相關性門檻的檢索資料"
                retrieval_info = {
                    "status": "not_found",
                    "message": f"未取得可用的 Excel／網路檢索證據（{detail}）。本輪仍由模型依一般知識回答，未經檢索資料查證。",
                    "requested_excel": use_retrieval, "requested_web": use_web_search,
                    "excel_count": 0, "web_count": 0, "source_count": 0,
                }

            if has_retrieved_evidence:
                messages[-1] = {"role": "user", "content": enhanced_prompt}
                yield encode_event({"type": "retrieval_status", "message": "檢索完成，正在整理證據並生成回答。"})
            elif use_retrieval or use_web_search:
                yield encode_event({"type": "retrieval_status", "message": retrieval_info["message"]})

            '''
            Request native streaming with the original model parameters.
            '''
            '''
            使用來源程式的原始模型參數，要求 Ollama 原生串流。
            '''
            current_stage = "Ollama 模型生成"
            stream = client.chat(
                model=MODEL_NAME,
                messages=messages,
                stream=True,
                keep_alive=KEEP_ALIVE,
                think=THINK,
                options=MODEL_OPTIONS,
            )

            '''
            Forward each genuine text fragment to the browser immediately.
            '''
            '''
            將模型實際產生的每段文字立即傳給瀏覽器。
            '''
            for stream_item in stream:
                '''
                Extract the plain text from the current stream item.
                '''
                '''
                從目前的串流資料取出純文字。
                '''
                chunk_text = extract_chunk_text(stream_item)

                '''
                Skip empty metadata fragments and preserve the received text.
                '''
                '''
                略過空白中繼資料片段，並保留實際收到的文字。
                '''
                if chunk_text:
                    '''
                    Add this fragment to the response that will be saved later.
                    '''
                    '''
                    將這段文字加入稍後要保存的完整回答。
                    '''
                    full_response += chunk_text

                    '''
                    Yield the current text fragment in NDJSON format.
                    '''
                    '''
                    以 NDJSON 格式傳出目前的文字片段。
                    '''
                    yield encode_event({"type": "chunk", "text": chunk_text})

            '''
            Reject empty model output and leave the history unchanged.
            '''
            '''
            若模型沒有產生文字，便拒絕保存並維持原歷史不變。
            '''
            if not full_response.strip():
                '''
                Inform the browser that the model returned an empty answer.
                '''
                '''
                通知瀏覽器模型回傳的是空白答案。
                '''
                yield encode_event({"type": "error", "message": "模型回傳空白內容，這一輪沒有寫入歷史紀錄。"})
                '''
                Stop the generator without saving an empty answer.
                '''
                '''
                空白回答不寫入歷史，並結束本輪串流。
                '''
                return

            '''
            Append both sides of the turn and save the complete history atomically.
            '''
            '''
            將本輪問答成對加入紀錄，並以原子方式保存完整歷史。
            '''
            current_stage = "保存聊天歷史"
            with history_lock:
                '''
                Reload current history before appending the completed turn.
                '''
                '''
                寫入本輪前重新載入最新歷史紀錄。
                '''
                current_history = load_history()

                '''
                Add the user's complete question to the stored conversation.
                '''
                '''
                將使用者完整問題加入已儲存的對話。
                '''
                current_history.append({"role": "user", "content": user_message})

                '''
                Add the assistant's complete answer to the stored conversation.
                '''
                '''
                將 assistant 完整回答加入已儲存的對話。
                '''
                assistant_record = {"role": "assistant", "content": full_response, "retrieval": retrieval_info}
                if source_items:
                    assistant_record["sources"] = source_items
                current_history.append(assistant_record)

                '''
                Persist the new history only after the model stream completes.
                '''
                '''
                只有模型串流完整結束後，才保存新的歷史紀錄。
                '''
                save_history(current_history)

            '''
            Signal success only after the complete conversation has been saved.
            '''
            '''
            只有完整對話成功保存後，才傳送成功事件。
            '''
            if source_items:
                yield encode_event({"type": "sources", "items": source_items})
            yield encode_event({"type": "retrieval_result", "retrieval": retrieval_info})
            yield encode_event({"type": "done"})

        except GeneratorExit:
            '''
            Propagate the disconnect signal to stop the incomplete stream.
            '''
            '''
            將斷線訊號繼續拋出，以停止未完成的串流。
            '''
            raise

        except Exception as error:
            '''
            Record a full traceback with the stage name to identify the true failure.
            '''
            '''
            記錄錯誤階段與完整堆疊，才能確認真正失敗的位置。
            '''
            app.logger.exception("Request failed during stage: %s", current_stage)

            '''
            Report errors according to the failing stage instead of blaming Ollama.
            '''
            '''
            依照實際失敗階段回報，不再一律誤顯示成 Ollama 錯誤。
            '''
            if current_stage == "Ollama 模型生成":
                error_message = friendly_ollama_error(error)
            elif current_stage == "保存聊天歷史":
                error_message = f"模型回覆已中斷，儲存歷史紀錄失敗（{type(error).__name__}）；本輪不會保存。"
            else:
                error_message = f"{current_stage}發生錯誤（{type(error).__name__}）；請查看啟動 Flask 的 CMD 視窗取得詳細原因。"
            yield encode_event({"type": "error", "message": error_message})

        finally:
            '''
            Make the server ready to accept the next chat or clear request.
            '''
            '''
            讓伺服器可以接受下一次聊天或清除請求。
            '''
            generation_lock.release()

    '''
    Return the generator as a streaming NDJSON HTTP response.
    '''
    '''
    將生成器包裝成 NDJSON HTTP 串流回應。
    '''
    return Response(
        stream_with_context(generate()),
        content_type="application/x-ndjson; charset=utf-8",
        headers={"Cache-Control": "no-cache", "X-Content-Type-Options": "nosniff"},
    )


'''
Clear the server-side conversation only when no generation is active.
'''

'''
只有沒有生成作業進行時，才清除伺服器端的對話紀錄。
'''
@app.post("/api/clear")
def clear_history():
    '''
    Refuse to clear the conversation while a response is being generated.
    '''
    '''
    回答生成期間拒絕清除對話，避免歷史資料互相覆寫。
    '''
    if not generation_lock.acquire(blocking=False):
        '''
        Refuse to clear history while the model is generating a reply.
        '''
        '''
        模型正在生成回答時，拒絕清除歷史紀錄。
        '''
        return jsonify({"error": "目前仍在回答中，請等候回答完成後再清除。"}), 409

    '''
    Delete the persistent file while holding the history lock.
    '''
    '''
    取得歷史檔案鎖後，刪除實際保存的歷史檔。
    '''
    try:
        '''
        Prevent a concurrent read or write while removing the history file.
        '''
        '''
        刪除歷史檔時避免同時發生讀取或寫入。
        '''
        with history_lock:
            '''
            Remove history.json when it exists; do not create an empty file.
            '''
            '''
            若 history.json 存在就刪除，不額外建立空檔案。
            '''
            HISTORY_FILE.unlink(missing_ok=True)

        '''
        Confirm that the server-side history has been cleared.
        '''
        '''
        確認伺服器端歷史紀錄已清除。
        '''
        return jsonify({"ok": True})

    except OSError:
        '''
        Return a safe explanation when the history file cannot be removed.
        '''
        '''
        歷史檔無法刪除時，回傳安全的錯誤說明。
        '''
        return jsonify({"error": "無法清除 history.json，請確認檔案沒有被其他程式占用。"}), 500

    finally:
        '''
        Release the generation lock after the clear request finishes.
        '''
        '''
        清除請求結束後，釋放生成作業的鎖。
        '''
        generation_lock.release()


'''
Start the Flask development server on the configured local-only address.
'''

'''
在設定的本機網址啟動 Flask 伺服器。
'''
try:
    INDEXED_EXCEL_DOCUMENTS = get_index_count()
    app.logger.info("Excel BM25 index ready: %s documents", INDEXED_EXCEL_DOCUMENTS)
except Exception as index_error:
    INDEXED_EXCEL_DOCUMENTS = 0
    app.logger.warning("Excel BM25 startup check failed: %s", type(index_error).__name__)


if __name__ == "__main__":
    '''
    Start without debug mode or the automatic reloader.
    '''
    '''
    啟動時關閉 debug 與自動 reloader。
    '''
    app.run(host=HOST, port=PORT, debug=False, use_reloader=False, threaded=True)

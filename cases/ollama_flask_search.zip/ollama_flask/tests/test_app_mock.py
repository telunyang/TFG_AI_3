"""Offline Flask/Ollama route contract tests using lightweight module stubs."""

import importlib
import json
import logging
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch

import retrieval


class FakeFlaskApp:
    def __init__(self, name):
        self.logger = logging.getLogger("test-flask")

    def get(self, path):
        return lambda function: function

    def post(self, path):
        return lambda function: function

    def run(self, **kwargs):
        return None


class FakeResponse:
    def __init__(self, response, **kwargs):
        self.response = response
        self.kwargs = kwargs


class FakeClient:
    def __init__(self):
        self.calls = []
        self.next_mode = "success"

    def chat(self, **kwargs):
        self.calls.append(kwargs)
        if self.next_mode == "error":
            raise RuntimeError("mock model failure")
        if self.next_mode == "empty":
            return iter(())
        return iter([
            {"message": {"content": "Mock "}},
            {"message": {"content": "answer"}},
        ])


class AppRouteMockTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.old_flask = sys.modules.get("flask")
        cls.old_ollama = sys.modules.get("ollama")
        request_stub = types.SimpleNamespace(payload={})
        request_stub.get_json = lambda silent=True: request_stub.payload
        flask_stub = types.ModuleType("flask")
        flask_stub.Flask = FakeFlaskApp
        flask_stub.Response = FakeResponse
        flask_stub.jsonify = lambda value: value
        flask_stub.render_template = lambda *args, **kwargs: "template"
        flask_stub.request = request_stub
        flask_stub.stream_with_context = lambda value: value
        ollama_stub = types.ModuleType("ollama")
        ollama_stub.Client = lambda **kwargs: FakeClient()
        sys.modules["flask"] = flask_stub
        sys.modules["ollama"] = ollama_stub
        sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
        cls.module = importlib.import_module("app")
        cls.module.client = FakeClient()
        cls.module.HISTORY_FILE = Path(tempfile.mkdtemp()) / "history.json"
        cls.request = request_stub

    @classmethod
    def tearDownClass(cls):
        try:
            cls.module.HISTORY_FILE.unlink(missing_ok=True)
            cls.module.HISTORY_FILE.parent.rmdir()
        except OSError:
            pass
        if cls.old_flask is None:
            sys.modules.pop("flask", None)
        else:
            sys.modules["flask"] = cls.old_flask
        if cls.old_ollama is None:
            sys.modules.pop("ollama", None)
        else:
            sys.modules["ollama"] = cls.old_ollama
        sys.modules.pop("app", None)

    def setUp(self):
        self.module.HISTORY_FILE.unlink(missing_ok=True)
        self.module.client = FakeClient()
        self.module.generation_lock = __import__("threading").Lock()
        self.module.history_lock = __import__("threading").Lock()
        self.module.app.logger = logging.getLogger("test-flask")

    def _stream(self, payload):
        self.request.payload = payload
        response = self.module.chat_stream()
        if isinstance(response, tuple):
            return response
        return [json.loads(line) for line in response.response]

    def test_legacy_api_and_no_retrieval_when_options_missing(self):
        with patch.object(self.module, "excel_search", side_effect=AssertionError("Excel must not be called")), \
             patch.object(self.module, "web_search", side_effect=AssertionError("DDGS must not be called")):
            events = self._stream({"message": "first question"})
        self.assertEqual(events[-1]["type"], "done")
        retrieval_event = next(event for event in events if event["type"] == "retrieval_result")
        self.assertEqual(retrieval_event["retrieval"]["status"], "not_requested")
        saved = json.loads(self.module.HISTORY_FILE.read_text(encoding="utf-8"))
        self.assertEqual(saved[-1]["retrieval"]["status"], "not_requested")
        self.assertEqual(self.module.get_history()["messages"][-1]["retrieval"]["status"], "not_requested")
        self.assertEqual(self.module.client.calls[0]["messages"][0]["role"], "system")
        self.assertEqual(len(self.module.client.calls[0]["messages"]), 2)

    def test_excel_sources_are_saved_and_not_sent_as_model_message_fields(self):
        document = {"title": "Excel note", "text": "臺灣 AI 模型資訊", "url": "https://example.org/note",
                    "file": "notes.xlsx", "sheet": "Sheet1", "row": 2, "score": 1.4}
        with patch.object(self.module, "excel_search", return_value=([document], "ok")), \
             patch.object(self.module, "web_search", side_effect=AssertionError("DDGS is not selected")):
            events = self._stream({"message": "臺灣 AI", "use_retrieval": True})
        self.assertEqual(events[-1]["type"], "done")
        source_event = next(event for event in events if event["type"] == "sources")
        self.assertEqual(source_event["items"][0]["source_type"], "excel")
        saved = json.loads(self.module.HISTORY_FILE.read_text(encoding="utf-8"))
        self.assertEqual(saved[-2]["content"], "臺灣 AI")
        self.assertEqual(saved[-1]["sources"][0]["url"], "https://example.org/note")
        model_messages = self.module.client.calls[0]["messages"]
        self.assertTrue(all(set(item) == {"role", "content"} for item in model_messages))
        self.assertIn("參考資料", model_messages[-1]["content"])

    def test_metadata_is_restored_but_not_injected_into_next_model_turn(self):
        first_document = {"title": "Source", "text": "some evidence text", "url": "https://example.org/source",
                          "file": "x.xlsx", "sheet": "A", "row": 2}
        with patch.object(self.module, "excel_search", return_value=([first_document], "ok")):
            self._stream({"message": "first", "use_retrieval": True})
        second_events = self._stream({"message": "second"})
        self.assertEqual(second_events[-1]["type"], "done")
        second_messages = self.module.client.calls[1]["messages"]
        self.assertEqual([item["role"] for item in second_messages], ["system", "user", "assistant", "user"])
        self.assertTrue(all(set(item) == {"role", "content"} for item in second_messages))
        history_result = self.module.get_history()
        self.assertIn("sources", history_result["messages"][1])


    def test_four_checkbox_combinations_call_only_selected_sources(self):
        with patch.object(self.module, "excel_search", return_value=([], "empty")) as excel_mock, \
             patch.object(self.module, "web_search", return_value=([], {"status": "no_match"})) as web_mock:
            self._stream({"message": "neither selected"})
            self.assertEqual(excel_mock.call_count, 0)
            self.assertEqual(web_mock.call_count, 0)
            self._stream({"message": "excel only", "use_retrieval": True})
            self.assertEqual(excel_mock.call_count, 1)
            self.assertEqual(web_mock.call_count, 0)
            excel_mock.reset_mock()
            self._stream({"message": "web only", "use_web_search": True})
            self.assertEqual(excel_mock.call_count, 0)
            self.assertEqual(web_mock.call_count, 1)
            excel_mock.reset_mock()
            web_mock.reset_mock()
            self._stream({"message": "both", "use_retrieval": True, "use_web_search": True})
            self.assertEqual(excel_mock.call_count, 1)
            self.assertEqual(web_mock.call_count, 1)

    def test_both_sources_are_combined_without_cross_upload(self):
        excel_doc = {"title": "Excel evidence", "text": "Excel only reference", "url": "https://example.org/xlsx",
                     "file": "class.xlsx", "sheet": "S", "row": 2}
        web_doc = {"title": "Web evidence", "text": "Web page body reference", "url": "https://example.org/web",
                   "relevance": 0.9, "cache_hit": False}
        with patch.object(self.module, "excel_search", return_value=([excel_doc], "ok")) as excel_mock, \
             patch.object(self.module, "web_search", return_value=([web_doc], {"status": "ok"})) as web_mock:
            events = self._stream({"message": "question", "use_retrieval": True, "use_web_search": True})
        self.assertEqual(excel_mock.call_count, 1)
        self.assertEqual(web_mock.call_count, 1)
        source_event = next(event for event in events if event["type"] == "sources")
        self.assertEqual({item["source_type"] for item in source_event["items"]}, {"excel", "web"})
        retrieval_event = next(event for event in events if event["type"] == "retrieval_result")
        self.assertEqual(retrieval_event["retrieval"]["status"], "used")
        saved_assistant = json.loads(self.module.HISTORY_FILE.read_text(encoding="utf-8"))[-1]
        self.assertEqual(saved_assistant["retrieval"]["excel_count"], 1)
        self.assertEqual(saved_assistant["retrieval"]["web_count"], 1)
        self.assertEqual(self.module.get_history()["messages"][-1]["retrieval"]["status"], "used")
        prompt = self.module.client.calls[0]["messages"][-1]["content"]
        self.assertIn("Excel only reference", prompt)
        self.assertIn("Web page body reference", prompt)


    def test_unexpected_ddgs_exception_is_reported_as_retrieval_and_chat_continues(self):
        with patch.object(self.module, "web_search", side_effect=TypeError("mock search response error")):
            events = self._stream({"message": "search question", "use_web_search": True})
        self.assertEqual(events[-1]["type"], "done")
        statuses = [event.get("message", "") for event in events if event["type"] == "retrieval_status"]
        self.assertTrue(any("DDGS 檢索發生未預期錯誤（TypeError）" in status for status in statuses))
        self.assertTrue(any(event["type"] == "chunk" for event in events))
        result = next(event["retrieval"] for event in events if event["type"] == "retrieval_result")
        self.assertEqual(result["status"], "not_found")
        self.assertIn("未經檢索資料查證", result["message"])
        saved = json.loads(self.module.HISTORY_FILE.read_text(encoding="utf-8"))
        self.assertEqual(saved[-2]["content"], "search question")
        self.assertEqual(saved[-1]["content"], "Mock answer")
        self.assertEqual(saved[-1]["retrieval"]["status"], "not_found")

    def test_retrieved_excel_without_url_is_marked_as_evidence_without_fabricated_source(self):
        document = {"title": "內部課堂筆記", "text": "臺灣 AI 模型課堂內容", "url": "",
                    "file": "notes.xlsx", "sheet": "Sheet1", "row": 2}
        with patch.object(self.module, "excel_search", return_value=([document], "ok")):
            events = self._stream({"message": "臺灣 AI", "use_retrieval": True})
        result = next(event["retrieval"] for event in events if event["type"] == "retrieval_result")
        self.assertEqual(result["status"], "used")
        self.assertEqual(result["excel_count"], 1)
        self.assertEqual(result["source_count"], 0)
        self.assertFalse(any(event["type"] == "sources" for event in events))
        restored = self.module.get_history()["messages"][-1]["retrieval"]
        self.assertEqual(restored["status"], "used")
        self.assertEqual(restored["source_count"], 0)

    def test_boolean_validation_and_failed_model_do_not_save_turn(self):
        self.assertEqual(self._stream({"message": "bad", "use_web_search": "true"})[1], 400)
        self.module.client.next_mode = "error"
        events = self._stream({"message": "will fail"})
        self.assertEqual(events[-1]["type"], "error")
        self.assertFalse(self.module.HISTORY_FILE.exists())
        self.module.client.next_mode = "empty"
        events = self._stream({"message": "empty output"})
        self.assertEqual(events[-1]["type"], "error")
        self.assertFalse(self.module.HISTORY_FILE.exists())


if __name__ == "__main__":
    unittest.main()

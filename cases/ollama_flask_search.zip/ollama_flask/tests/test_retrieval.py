"""Mock-based offline tests for workbook indexing, web ranking, and the cache."""

import shutil
import tempfile
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from threading import Thread
from pathlib import Path
from unittest.mock import patch

import numpy as np
from openpyxl import Workbook, load_workbook
import retrieval


class FakeJieba:
    """Minimal Chinese tokenizer stand-in for offline tests without jieba installed."""

    @staticmethod
    def lcut(text):
        return [text[index:index + 2] for index in range(max(1, len(text) - 1))]


class FakeBM25L:
    """Small deterministic BM25 stand-in used only because CI has no rank-bm25 package."""

    built_count = 0

    def __init__(self, corpus):
        type(self).built_count += 1
        self.corpus = corpus

    def get_scores(self, query_tokens):
        scores = []
        query = set(query_tokens)
        for tokens in self.corpus:
            overlap = query.intersection(tokens)
            scores.append(float(len(overlap)) if overlap else 0.0)
        return scores


class FakeDDGS:
    calls = []

    def __init__(self, timeout=5):
        self.timeout = timeout

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False

    def text(self, query, max_results=10):
        self.calls.append((query, max_results, self.timeout))
        return [
            {"title": "Green energy policy", "href": "https://example.org/energy", "body": "summary only"},
            {"title": "Duplicate", "href": "https://example.org/energy", "body": "duplicate candidate"},
        ]

    def news(self, query, max_results=10):
        return self.text(query, max_results)


class RetrievalTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.mkdtemp(prefix="bm25-fixture-")
        self.old_data = retrieval.DATA_DIR
        self.old_cache = retrieval.CACHE_FILE
        self.old_index = retrieval.INDEX_FILE
        self.old_model = retrieval.BM25L
        self.old_jieba = retrieval.jieba
        self.old_ddgs = retrieval.DDGS
        self.old_threshold = retrieval.MIN_BM25_SCORE
        self.old_fetch = retrieval._fetch_page
        self.old_state = dict(retrieval.INDEX_STATE)
        retrieval.DATA_DIR = Path(self.temp) / "data"
        retrieval.DATA_DIR.mkdir()
        retrieval.CACHE_FILE = retrieval.DATA_DIR / "web_cache.xlsx"
        retrieval.INDEX_FILE = Path(self.temp) / "bm25_index.pkl"
        retrieval.BM25L = FakeBM25L
        retrieval.jieba = FakeJieba
        retrieval.DDGS = FakeDDGS
        retrieval.MIN_BM25_SCORE = 0.1
        retrieval.INDEX_STATE.update({"fingerprint": None, "stats": None, "documents": [], "tokens": [], "bm25": None})
        FakeDDGS.calls = []
        FakeBM25L.built_count = 0
        self.workbook_path = retrieval.DATA_DIR / "class_notes.xlsx"
        self._make_workbook()

    def tearDown(self):
        retrieval.DATA_DIR = self.old_data
        retrieval.CACHE_FILE = self.old_cache
        retrieval.INDEX_FILE = self.old_index
        retrieval.BM25L = self.old_model
        retrieval.jieba = self.old_jieba
        retrieval.DDGS = self.old_ddgs
        retrieval.MIN_BM25_SCORE = self.old_threshold
        retrieval._fetch_page = self.old_fetch
        retrieval.INDEX_STATE.update(self.old_state)
        shutil.rmtree(self.temp, ignore_errors=True)

    def _make_workbook(self):
        workbook = Workbook()
        sheet = workbook.active
        sheet.title = "課程資料"
        sheet.append(["標題", "摘要", "內文", "關鍵字", "來源網址", "識別碼"])
        sheet.append(["臺灣 AI 模型", "臺灣人工智慧模型介紹", "臺灣 AI 模型與 machine learning 的應用", "AI 模型", "https://example.org/tw", "1001"])
        sheet.append(["Green energy policy", "Renewable energy policy", "Solar energy and clean power policy in Europe", "green energy", None, "1002"])
        workbook.save(self.workbook_path)
        workbook.close()

    def test_restart_loads_trusted_index_without_retokenizing_or_rebuilding(self):
        retrieval.ensure_excel_index()
        self.assertEqual(FakeBM25L.built_count, 1)
        retrieval.INDEX_STATE.update({"fingerprint": None, "stats": None, "documents": [], "tokens": [], "bm25": None})
        with patch.object(retrieval, "_read_excel_documents", side_effect=AssertionError("Excel read should be skipped")), \
             patch.object(retrieval, "tokenize", side_effect=AssertionError("Tokenizer should not be rerun")):
            count = retrieval.ensure_excel_index()
        self.assertEqual(count, 2)
        self.assertEqual(FakeBM25L.built_count, 1)

    def test_chinese_english_and_mixed_queries(self):
        zh, status_zh = retrieval.excel_search("臺灣 AI 模型")
        en, status_en = retrieval.excel_search("green energy policy")
        mixed, status_mixed = retrieval.excel_search("臺灣 AI energy")
        self.assertEqual(status_zh, "ok")
        self.assertEqual(status_en, "ok")
        self.assertEqual(status_mixed, "ok")
        self.assertIn("臺灣", zh[0]["title"])
        self.assertIn("Green", en[0]["title"])

    def test_threshold_and_unmatched_query(self):
        retrieval.MIN_BM25_SCORE = 1000
        matches, status = retrieval.excel_search("臺灣 AI 模型")
        self.assertEqual(matches, [])
        self.assertEqual(status, "no_match")
        matches, status = retrieval.excel_search("unrelated zebra astronomy")
        self.assertEqual(matches, [])

    def test_cache_reuse_change_rebuild_and_delete_last_workbook(self):
        retrieval.ensure_excel_index()
        first_fingerprint = retrieval.INDEX_STATE["fingerprint"]
        with patch.object(retrieval, "_read_excel_documents", wraps=retrieval._read_excel_documents) as reader:
            retrieval.ensure_excel_index()
            self.assertEqual(reader.call_count, 0)
            workbook = load_workbook(self.workbook_path)
            workbook["課程資料"].append(["New AI", "New content", "New AI lesson", "AI", None, "1003"])
            workbook.save(self.workbook_path)
            workbook.close()
            retrieval.ensure_excel_index()
            self.assertEqual(reader.call_count, 1)
        self.assertNotEqual(first_fingerprint, retrieval.INDEX_STATE["fingerprint"])
        self.workbook_path.unlink()
        self.assertEqual(retrieval.ensure_excel_index(), 0)
        self.assertEqual(retrieval.excel_search("臺灣 AI")[0], [])

    def test_invalid_or_missing_url_never_creates_empty_source(self):
        docs = [{"title": "Example", "text": "useful text", "url": "", "file": "a.xlsx", "sheet": "S", "row": 2}]
        prompt, sources = retrieval.build_retrieval_prompt(docs, [], "query")
        self.assertIn("useful text", prompt)
        self.assertEqual(sources, [])
        docs[0]["url"] = "javascript:alert(1)"
        self.assertEqual(retrieval.build_retrieval_prompt(docs, [], "query")[1], [])

    def test_url_normalization_and_ssrf_private_ip_rejection(self):
        normalized = retrieval.normalize_url("https://example.org/中文 路徑?q=測試#fragment")
        self.assertTrue(normalized.startswith("https://example.org/"))
        self.assertNotIn("#fragment", normalized)
        with patch.object(retrieval.socket, "getaddrinfo", return_value=[(2, 1, 6, "", ("127.0.0.1", 80))]):
            with self.assertRaises(ValueError):
                retrieval._resolve_public_ip("rebind.example", 80)

    def test_web_candidate_dedup_body_ranking_and_cache_hit(self):
        body = "Green energy policy supports clean power. Solar energy policy improves renewable energy planning. " * 12
        fetch_calls = []

        def fake_fetch(url, etag=None, last_modified=None):
            fetch_calls.append(url)
            return {"status": 200, "url": url, "text": body, "etag": '"v1"', "last_modified": None}

        retrieval._fetch_page = fake_fetch
        first, first_status = retrieval.web_search("green energy policy")
        second, second_status = retrieval.web_search("green energy policy")
        self.assertTrue(first)
        self.assertEqual(first_status["status"], "ok")
        self.assertEqual(second_status["cache_hit"], True)
        self.assertEqual(len(fetch_calls), 1)
        self.assertEqual(len(FakeDDGS.calls), 1)
        self.assertEqual(first[0]["url"], "https://example.org/energy")
        workbook = load_workbook(retrieval.CACHE_FILE, read_only=True, data_only=True)
        self.assertGreater(workbook["chunks"].max_row, 1)
        self.assertGreater(workbook["pages"].max_row, 1)
        workbook.close()


    def test_requests_body_extraction_removes_navigation_and_validates_redirects(self):
        page_text = "正文內容包含 green energy policy。" * 30

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                if self.path == "/redirect":
                    self.send_response(302)
                    self.send_header("Location", "http://private.test/admin")
                    self.end_headers()
                    return
                body = ("<html><body><nav>Navigation noise</nav><script>evil()</script>"
                        f"<article><h1>Title</h1><p>{page_text}</p></article></body></html>").encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, *args):
                return

        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = Thread(target=server.serve_forever, daemon=True)
        thread.start()
        base_url = f"http://test-public.example:{server.server_port}"
        try:
            with patch.object(retrieval, "_resolve_public_ip", return_value=(2, "127.0.0.1")):
                result = retrieval._fetch_page(base_url + "/article")
            self.assertIn("正文內容", result["text"])
            self.assertNotIn("Navigation noise", result["text"])
            self.assertNotIn("evil()", result["text"])
            with patch.object(retrieval, "_resolve_public_ip", side_effect=[(2, "127.0.0.1"), ValueError("private IP blocked")]):
                with self.assertRaises(ValueError):
                    retrieval._fetch_page(base_url + "/redirect")
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=2)


    def test_web_bm25_accepts_numpy_score_array_without_truth_value_error(self):
        body = "green energy policy evidence supports clean renewable electricity." * 20

        class NumpyScoreBM25(FakeBM25L):
            def get_scores(self, query_tokens):
                return np.asarray(super().get_scores(query_tokens), dtype=float)

        retrieval.BM25L = NumpyScoreBM25
        retrieval._fetch_page = lambda url, etag=None, last_modified=None: {
            "status": 200, "url": url, "text": body, "title": "Energy evidence",
            "published_date": "", "etag": None, "last_modified": None,
        }
        results, status = retrieval.web_search("green energy policy")
        self.assertEqual(status["status"], "ok")
        self.assertTrue(results)
        self.assertEqual(results[0]["url"], "https://example.org/energy")

    def test_web_query_retries_then_uses_second_round(self):
        body = "green energy policy evidence supports cleaner electricity." * 20
        retrieval._fetch_page = lambda url, etag=None, last_modified=None: {
            "status": 200, "url": url, "text": body, "title": "Fallback result", "published_date": "",
            "etag": None, "last_modified": None,
        }
        with patch("retrieval.time.sleep", return_value=None), \
             patch.object(retrieval, "_ddgs_search", side_effect=[RuntimeError("No results found")] * 3 + [[
                 {"title": "Fallback", "href": "https://example.org/fallback", "body": "snippet"}
             ]]) as search_mock:
            result, status = retrieval.web_search("Green Energy Policy!")
        self.assertEqual(search_mock.call_count, 4)
        self.assertEqual(status["status"], "ok")
        self.assertTrue(result)

    def test_all_ddgs_attempts_failed_return_error_without_caching_empty_result(self):
        with patch("retrieval.time.sleep", return_value=None), \
             patch.object(retrieval, "_ddgs_search", side_effect=RuntimeError("offline")) as search_mock:
            results, status = retrieval.web_search("green energy policy")
        self.assertEqual(results, [])
        self.assertEqual(status["status"], "error")
        self.assertEqual(search_mock.call_count, retrieval.WEB_MAX_SEARCH_ATTEMPTS)
        workbook = load_workbook(retrieval.CACHE_FILE, read_only=True, data_only=True)
        self.assertEqual(workbook["queries"].max_row, 1)
        workbook.close()

    def test_page_retry_honors_retry_after_and_does_not_retry_403(self):
        response_429 = retrieval.requests.Response()
        response_429.status_code = 429
        response_429.headers["Retry-After"] = "0"
        error_429 = retrieval.requests.HTTPError("rate limited", response=response_429)
        success = {"status": 200, "url": "https://example.org/page", "text": "body"}
        with patch.object(retrieval, "_fetch_page", side_effect=[error_429, success]) as fetch_mock, \
             patch("retrieval.time.sleep", return_value=None), \
             patch("retrieval.random.uniform", return_value=0):
            fetched = retrieval._fetch_page_with_retries("https://example.org/page")
        self.assertEqual(fetched["status"], 200)
        self.assertEqual(fetch_mock.call_count, 2)

        response_403 = retrieval.requests.Response()
        response_403.status_code = 403
        error_403 = retrieval.requests.HTTPError("forbidden", response=response_403)
        with patch.object(retrieval, "_fetch_page", side_effect=error_403) as fetch_mock:
            with self.assertRaises(retrieval.requests.HTTPError):
                retrieval._fetch_page_with_retries("https://example.org/private")
        self.assertEqual(fetch_mock.call_count, 1)

    def test_web_cache_has_required_sheets_and_ignores_it_for_excel(self):
        retrieval._ensure_web_cache()
        workbook = load_workbook(retrieval.CACHE_FILE, read_only=True)
        self.assertEqual(set(workbook.sheetnames), {"queries", "pages", "chunks"})
        workbook.close()
        self.assertEqual(retrieval._excel_fingerprint(), retrieval._excel_fingerprint())


if __name__ == "__main__":
    unittest.main()
